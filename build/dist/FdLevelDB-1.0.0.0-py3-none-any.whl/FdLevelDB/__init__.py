from FdLevelDB import leveldb

version = __version__ = "1.0.0.0"

print('Running FdLevelDB', version)

__all__ = [
        'FdLevelDB',
        ]
